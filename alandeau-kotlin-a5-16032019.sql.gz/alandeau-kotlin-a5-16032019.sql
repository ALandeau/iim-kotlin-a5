# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Hôte: 127.0.0.1 (MySQL 5.6.38)
# Base de données: CMS
# Temps de génération: 2019-03-16 20:51:02 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Affichage de la table articles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;

INSERT INTO `articles` (`id`, `title`, `text`)
VALUES
	(1,'article test 1','Aliquam est ut accusamus illo quae delectus. Cupiditate esse labore voluptate consequatur. Molestiae qui est deleniti qui reprehenderit. Ex eligendi magnam aut sapiente minus. Molestias quaerat nemo veritatis voluptatem ut aut iure nobis.\r\n\r\nLaudantium facere corporis ut aut reprehenderit. Sit eveniet sunt aut doloribus quibusdam et veritatis. Ad illum accusantium minima voluptatibus incidunt voluptas dignissimos. Similique est sint repellendus.'),
	(2,'Article test 2','Omnis explicabo adipisci provident itaque unde qui. Sit praesentium omnis necessitatibus et voluptatum. Harum id debitis libero.\r\n\r\nIn ea quis qui suscipit qui asperiores pariatur. Sint soluta rerum quis saepe. Rerum quaerat laborum ratione aut.\r\n\r\nTemporibus temporibus voluptatem voluptatem. Deleniti consequuntur aut eum consequatur numquam consequatur. Doloremque sit eos qui. Eum sunt deleniti exercitationem. Hic voluptate est quaerat qui laudantium.\r\n\r\nLibero consequuntur dolor qui. Consequatur reiciendis consequatur doloribus laudantium voluptatem voluptatem in. Voluptas facere repellat corrupti rem impedit et. Atque quaerat blanditiis culpa ipsa quis. Sint optio mollitia atque molestias aut non.');

/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `text` text,
  `article_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `article_id` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;

INSERT INTO `comments` (`id`, `text`, `article_id`)
VALUES
	(2,'Ab neque nisi dolores aut ut odit odit rerum. Dicta unde officiis sit quam quisquam. Cumque voluptatem accusamus sed ut ex.',1),
	(3,'ceci est un commentaire sur le deuxième article',2);

/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `username`, `password`)
VALUES
	(0,'admin','admin');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
